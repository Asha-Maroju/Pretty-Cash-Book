document.addEventListener('DOMContentLoaded', () => {
    const incomeForm = document.getElementById('income-form');
    const expenseForm = document.getElementById('expense-form');
    const cashBookTable = document.getElementById('cash-book').getElementsByTagName('tbody')[0];

    let balance = 0;

    incomeForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const date = document.getElementById('income-date').value;
        const description = document.getElementById('income-description').value;
        const amount = parseFloat(document.getElementById('income-amount').value);

        balance += amount;
        addRow(date, description, amount, null, balance);
        incomeForm.reset();
    });

    expenseForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const date = document.getElementById('expense-date').value;
        const description = document.getElementById('expense-description').value;
        const amount = parseFloat(document.getElementById('expense-amount').value);

        balance -= amount;
        addRow(date, description, null, amount, balance);
        expenseForm.reset();
    });

    function addRow(date, description, income, expense, balance) {
        const row = cashBookTable.insertRow();
        row.insertCell(0).textContent = date;
        row.insertCell(1).textContent = description;
        row.insertCell(2).textContent = income !== null ? income.toFixed(2) : '';
        row.insertCell(3).textContent = expense !== null ? expense.toFixed(2) : '';
        row.insertCell(4).textContent = balance.toFixed(2);
    }
});
